/*
** main.c for printf in /home/lombar_e/rendu/test
**
** Made by Thomas Lombard
** Login   <lombar_e@epitech.net>
**
** Started on  Fri Dec 18 10:35:32 2016 Thomas Lombard
** Last update Sun Nov 20 00:33:13 2016 Thomas Lombard
*/

#include <stdlib.h>
#include <math.h>
#include <pwd.h>
#include <limits.h>
#include <sys/time.h>
#include "header.h"

/*
** Project name : {{PROJECT}}
*/

#define m_free(val) (free(val), val = NULL)

int		main()
{
  char		str1[]		= "Ok";
  char		str2[]		= "Lorem ipsum dolor sit amet, consectetur adipisicing elit";
  char		special[]	= "\atata\t\n\033avec les \tet \\t";
  char		special2[]	= "OK I go take coffee .........";
  char		*str3		= NULL;
  char		char1		= 'A';
  char		char2		= ' ';
  int		int1		= 0;
  int		int2		= 23;
  int		int3		= 1928;
  int		int4		= INT_MIN;
  int		int5		= INT_MAX;
  unsigned int	uint1		= 2398;
  unsigned int	uint2		= UINT_MAX;
  unsigned int	uint3		= 0;
  double	double1		= 2.0;
  double	double2		= 2374.231;
  double	double3		= 23.9981;
  long int	long1		= 2387648127686;
  long int	long2		= LONG_MIN;
  long int	long3		= LONG_MAX;
  size_t	p = 1;
  char		*pause = NULL;
    char	*cup[49] = {"                                    o$$$$$$oo",
		    "                                 o$\"        \"$oo",
		    "                                 $   o\"\"\"\"$o  \"$o",
		    "                                \"$  o  \"o  \"o   $",
		    "                                \"$   $o $   $   o$",
		    "                                 \"$       o$\"$  o$",
		    "                                  \"$ooooo$$  $  o$",
		    "                        o$ \"\"\" $     \" $$$   \"  $",
		    "                      o$        $o    $$\"   \"   \"",
		    "                     $$  $ \" $   $$$o\"$    o  o$\"",
		    "                     $\"  o \"\" $   $\" \"   o\"  $$",
		    "                     $o  \" \"  $  o$\"   o\"  o$\"",
		    "                      \"$o    $$  $   o\"  o$$\"",
		    "                       \"\"o$o\"$\"  $oo\"  o$\"",
		    "                        o$$ $   $$$  o$$",
		    "                        o\" o oo\"\"  \"\" \"$o",
		    "                       o$o\" \"\"          $",
		    "                      $\" \" o\"   \" \" \"   \"o",
		    "                     $$ \"  \"  o$ o$o \"   $",
		    "                    o$ $  $  o$$ \"  \"   \"\"",
		    "                    o  $ $\"  \" \"o      o$",
		    "                    $ o         $o$oo$\"\"",
		    "                   $o $   o  o  o\"$$",
		    "                   $o  o  $  $    \"$o",
		    "                   $o  $   o  $  $ \"o",
		    "                    $  $   \"o  $  \"o\"$o",
		    "                    $   \"   o   $   o $$",
		    "            $o$o$o$o$$o$$$o$$o$o$$o$$o$$$o$o$o$o$o$o$o$o$o$ooo",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$   \" $$$$$",
		    "            $$$$$$$$                           $$$$$$$$      \"$$$$",
		    "            $$$$$$      PLEASE BE GENEROUS       $$$$$$       $$$$",
		    "            $$$$$$       WITH YOUR GRADE         $$$$$$       $$$$",
		    "            $$$$$$                               $$$$$$       $$$$",
		    "            $$$$$$     \033[5;31m",
		    "\033[0m      $$$$$$     o$$$$\"",
		    "            $$$$$$                               $$$$$$ooooo$$$$",
		    "            $$$$$$       \033[5;31mTHE BEST AER EVER\033[m       $$$$$$$$$$$$$\"",
		    "            $$$$$$$$                           $$$$$$$$\"\"\"\"\"",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",
		    "            $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\"",
		    "\"$o$o$o$o$o$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\"",
		    "  \"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\"",
		    "    \"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\"\"\"",
		    "       \"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"", NULL};
  int		i = 0, len = 0;
  struct timeval stop, start;
  struct passwd *pw;
  uid_t uid;


  gettimeofday(&start, NULL);
  my_printf("Welcome to my main test function.\nThis main test are composed of 215 tests splited in 4 categories.\n");
  my_printf("To access to the next sequence, you have to press the enter key.\n");
  my_printf("Every prints of this program are made with the my_printf function.\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");
  my_printf("-----\n\tSimple flag tests\n");
  my_printf("Following a series of tests containing all only 1 flag\n-----\n\n");

  my_printf("Strings tests :\n-\033[32m");
  my_printf("%s", str1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%s", str2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%s", str3);
  my_printf("\033[m-\n\n");

  my_printf("Chars Tests :\n-\033[32m");
  my_printf("%c", char1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%c", char2);
  my_printf("\033[m-\n\n");

  my_printf("Special print tests :\n-\033[32m");
  my_printf("%S", special);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%S", "\a\177");
  my_printf("\033[m-\n\n");

  my_printf("Decimal tests :\n-\033[32m");
  my_printf("%d", int1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%d", int2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%d", int3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%d", int4);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%d", int5);
  my_printf("\033[m-\n\n");

  my_printf("Integer tests :\n-\033[32m");
  my_printf("%i", int1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%i", int2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%i", int3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%i", int4);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%i", int5);
  my_printf("\033[m-\n\n");

  my_printf("Unsigned tests :\n-\033[32m");
  my_printf("%u", uint1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%u", uint2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%u", uint3);
  my_printf("\033[m-\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");

  my_printf("Binary tests :\n-\033[32m");
  my_printf("%b", uint1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%b", uint2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%b", uint3);
  my_printf("\033[m-\n\n");

  my_printf("Octal tests :\n-\033[32m");
  my_printf("%o", uint1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%o", uint2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%o", uint3);
  my_printf("\033[m-\n\n");

  my_printf("hexa tests :\n-\033[32m");
  my_printf("%x", uint1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%x", uint2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%x", uint3);
  my_printf("\033[m-\n\n");

  my_printf("HEXA tests :\n-\033[32m");
  my_printf("%X", uint1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%X", uint2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%X", uint3);
  my_printf("\033[m-\n\n");

  my_printf("float / double tests :\n-\033[32m");
  my_printf("%f", double1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%f", double2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%f", double3);
  my_printf("\033[m-\n\n");

  my_printf("FLOAT / double tests :\n-\033[32m");
  my_printf("%F", double1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%F", double2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%F", double3);
  my_printf("\033[m-\n\n");

  my_printf("Modulo Test :\n-\033[32m");
  my_printf("%%", double1);
  my_printf("\033[m-\n\n");

  my_printf("N Test :\n-\033[32m");
  my_printf("%n");
  my_printf("\033[m-\n\n");

  my_printf("Pointer Test :\n-\033[32m");
  my_printf("%p", str1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%p", str2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("%p", str3);
  my_printf("\033[m-\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");


  my_printf("-----\n\tNormals tests\n");
  my_printf("Following a series of tests with all 2 or more flags\n-----\n\n");

  my_printf("Multiple strings tests :\n-\033[32m");
  my_printf("%s\033[33mand\033[32m%S", str1, special);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mThis test are basic\033[32m%s\033[33manother string\033[32m%S", str2, str3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying to print s S and c\033[32m%s%S%c", str1, "toto\n", 'a');
  my_printf("\033[m-\n\n");

  my_printf("Multiple int tests :\n-\033[32m");
  my_printf("%d\033[33mand\033[32m%i", rand(), rand());
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mCan print every types of int flags in one call ??\033[32m %i %d %b %o %x %X", rand(), -rand(), -rand(), rand(), rand(), rand());
  my_printf("\033[m-\n\n");

  my_printf("Mixed strings / int / float tests\n-\033[32m");
  my_printf("\033[33mMy birth date are\033[32m %i %s %d\033[33m at \033[32m%b:%o:%x %S", 15, "june", 1997, 6, 43, 6, "PM");
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mSo pretty no ??\033[32m");
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mI have \033[32m%f\033[33m general average at High School \033[32m%s %F", 16.43, "famous pool of EPITECH", -2.45);
  my_printf("\033[m-\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");

  my_printf("-----\n\tComplex flags tests\n");
  my_printf("Following a series of tests with all 2 or more flags plus modifiers\n-----\n\n");

  my_printf("Converters tests :\n-\033[32m");
  my_printf("\033[33mTry with long decimal 1 - - - - \033[32m%ld", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry with long decimal 2 - - - - \033[32m%ld", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry with long decimal 3 - - - - \033[32m%ld", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long integer 1 - - \033[32m%li", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long integer 2 - - \033[32m%li", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long integer 3 - - \033[32m%li", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long binary 1 - -  \033[32m%lb", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long binary 2 - -  \033[32m%lb", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long binary 3 - -  \033[32m%lb", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long octal 1 - - - \033[32m%lo", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long octal 2 - - - \033[32m%lo", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long octal 3 - - - \033[32m%lo", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long hexa 1 - - -  \033[32m%lx", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long hexa 2 - - -  \033[32m%lx", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long hexa 3 - - -  \033[32m%lx", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long HEXA 1 - - -  \033[32m%lX", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long HEXA 2 - - -  \033[32m%lX", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with long HEXA 3 - - -  \033[32m%lX", long3);
  my_printf("\033[m-\n\n-");

  my_printf("\033[33mTry with short decimal 1 - - - - \033[32m%hd", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry with short decimal 2 - - - - \033[32m%hd", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry with short decimal 3 - - - - \033[32m%hd", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short integer 1 - - \033[32m%hi", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short integer 2 - - \033[32m%hi", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short integer 3 - - \033[32m%hi", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short binary 1 - -  \033[32m%hb", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short binary 2 - -  \033[32m%hb", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short binary 3 - -  \033[32m%hb", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short octal 1 - - - \033[32m%ho", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short octal 2 - - - \033[32m%ho", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short octal 3 - - - \033[32m%ho", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short hexa 1 - - -  \033[32m%hx", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short hexa 2 - - -  \033[32m%hx", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short hexa 3 - - -  \033[32m%hx", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short HEXA 1 - - -  \033[32m%hX", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short HEXA 2 - - -  \033[32m%hX", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with short HEXA 3 - - -  \033[32m%hX", SHRT_MAX);
  my_printf("\033[m-\n\n-");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);

  my_printf("\033[33mTry with char decimal 1 - - - - \033[32m%hhd", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry with char decimal 2 - - - - \033[32m%hhd", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry with char decimal 3 - - - - \033[32m%hhd", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char integer 1 - - \033[32m%hhi", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char integer 2 - - \033[32m%hhi", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char integer 3 - - \033[32m%hhi", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char binary 1 - -  \033[32m%hhb", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char binary 2 - -  \033[32m%hhb", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char binary 3 - -  \033[32m%hhb", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char octal 1 - - - \033[32m%hho", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char octal 2 - - - \033[32m%hho", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char octal 3 - - - \033[32m%hho", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char hexa 1 - - -  \033[32m%hhx", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char hexa 2 - - -  \033[32m%hhx", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char hexa 3 - - -  \033[32m%hhx", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char HEXA 1 - - -  \033[32m%hhX", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char HEXA 2 - - -  \033[32m%hhX", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTry now with char HEXA 3 - - -  \033[32m%hhX", CHAR_MAX);
  my_printf("\033[m-\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");

  my_printf("Modifiers tests :\n-\033[32m");
  my_printf("\033[33mTrying modifiers with long decimal 1 - -  \033[32m%#ld", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying modifiers with long decimal 2 - -  \033[32m%#ld", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying modifiers with long decimal 3 - -  \033[32m%#ld", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long integer 1  \033[32m%#li", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long integer 2  \033[32m%#li", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long integer 3  \033[32m%#li", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long binary 1 - \033[32m%#lb", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long binary 2 - \033[32m%#lb", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long binary 3 - \033[32m%#lb", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long octal 1 -  \033[32m%#lo", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long octal 2 -  \033[32m%#lo", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long octal 3 -  \033[32m%#lo", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long hexa 1 - - \033[32m%#lx", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long hexa 2 - - \033[32m%#lx", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long hexa 3 - - \033[32m%#lx", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long HEXA 1 - - \033[32m%#lX", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long HEXA 2 - - \033[32m%#lX", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with long HEXA 3 - - \033[32m%#lX", long3);
  my_printf("\033[m-\n\n-");

  my_printf("\033[33mTrying modifiers with short decimal 1 - - - \033[32m%#hd", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying modifiers with short decimal 2 - - - \033[32m%#hd", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying modifiers with short decimal 3 - - - \033[32m%#hd", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short integer 1 - \033[32m%#hi", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short integer 2 - \033[32m%#hi", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short integer 3 - \033[32m%#hi", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short binary 1 -  \033[32m%#hb", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short binary 2 -  \033[32m%#hb", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short binary 3 -  \033[32m%#hb", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short octal 1 - - \033[32m%#ho", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short octal 2 - - \033[32m%#ho", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short octal 3 - - \033[32m%#ho", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short hexa 1 - -  \033[32m%#hx", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short hexa 2 - -  \033[32m%#hx", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short hexa 3 - -  \033[32m%#hx", SHRT_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short HEXA 1 - -  \033[32m%#hX", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short HEXA 2 - -  \033[32m%#hX", SHRT_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with short HEXA 3 - -  \033[32m%#hX", SHRT_MAX);
  my_printf("\033[m-\n\n-");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);

  my_printf("\033[33mTrying modifiers with char decimal 1 - - - - - \033[32m%#hhd", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying modifiers with char decimal 2 - - - - - \033[32m%#hhd", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying modifiers with char decimal 3 - - - - - \033[32m%#hhd", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char integer 1 - - - \033[32m%#hhi", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char integer 2 - - - \033[32m%#hhi", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char integer 3 - - - \033[32m%#hhi", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char binary 1 - - -  \033[32m%#hhb", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char binary 2 - - -  \033[32m%#hhb", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char binary 3 - - -  \033[32m%#hhb", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char octal 1 - - - - \033[32m%#hho", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char octal 2 - - - - \033[32m%#hho", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char octal 3 - - - - \033[32m%#hho", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char hexa 1 - - - -  \033[32m%#hhx", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char hexa 2 - - - -  \033[32m%#hhx", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char hexa 3 - - - -  \033[32m%#hhx", CHAR_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char HEXA 1 - - - -  \033[32m%#hhX", 0);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char HEXA 2 - - - -  \033[32m%#hhX", CHAR_MIN);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now modifiers with char HEXA 3 - - - -  \033[32m%#hhX", CHAR_MAX);
  my_printf("\033[m-\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");

  my_printf("Formating tests :\n-\033[32m");
  my_printf("\033[33mTrying format with min 33 chars - - - - - - - - - - - - \033[32m%33ld", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying format with min 34 chars and write at right - -  \033[32m%+34ld", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying format with min 58 chars and write at left - - - \033[32m%-58ld", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format with min 33 chars - - - - - - - - - - \033[32m%33li", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format with min 34 chars and write at right  \033[32m%+34li", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format with min 58 chars and write at left - \033[32m%-58li", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format wit min 33 chars - - - - - - - - - -  \033[32m%33lb", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format withmin 34 chars and write at right - \033[32m%+34lb", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format withmin 58 chars and write at left -  \033[32m%-58lb", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format wi min 33 chars - - - - - - - - - - - \033[32m%33lo", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format witmin 34 chars and write at right -  \033[32m%+34lo", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format witmin 58 chars and write at left - - \033[32m%-58lo", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format w min 33 chars - - - - - - - - - - -  \033[32m%33lx", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format wimin 34 chars and write at right - - \033[32m%+34lx", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format wimin 58 chars and write at left - -  \033[32m%-58lx", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format w min 33 chars - - - - - - - - - - -  \033[32m%33lX", long1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format wimin 34 chars and write at right - - \033[32m%+34lX", long2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mTrying now format wimin 58 chars and write at left - -  \033[32m%-58lX", long3);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mWhat's doing with float values ?? - - - - - - - - - - - \033[32m%2.3f", double1);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mWhat's doing with float values ?? - - - - - - - - - - - \033[32m%3.7f", double2);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mWhat's doing with float values ?? - - - - - - - - - - - \033[32m%10.10f", double3);
  my_printf("\033[m-\n\n");
  my_printf("Press enter to continue :");
  getline(&pause, &p, stdin);
  m_free(pause);
  my_printf("\033[3;J\033[H\033[2J");

  my_printf("-----\n\tRandom never used flags ^^\n");
  my_printf("Following a series of tests never used in other case of debuging\n-----\n\n");
  my_printf("\033[33mWhat's printf does if I use \033[32m%%+32s%%-23S%%34d%%%%%%f%%#+32lX\033[33m ?? \033[32m%+32s%-23S%34d%%%f%#+32X", "If it's OK", "I'll print \n\t\003\001", 234, 23.34, LONG_MAX);
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mOMFG It's works !!!!");
  my_printf("\033[m-\n-\033[32m");
  my_printf("\033[33mSo remember that, one day a guy said \"\033[32m%s%#+5X\033[33mtter when it's free\". \033[32m%S\033[33m since \033[32m%#o", "Software is like Sex. It's", 0xBE, "Linus Torvalds", 1996);
  my_printf("\033[m-\n\n");
  my_printf("Ok it's the end of my_printf tests. Let me show you some statistics\n");
  my_printf("In this test main, my_printf where called %d times.\n", 466);
  gettimeofday(&stop, NULL);

  my_printf("Execute time are %lu microseconds .... OK it take %.6f seconds\n", stop.tv_usec - start.tv_usec, (double)((stop.tv_usec - start.tv_usec) / 1000000.0));
  my_printf("It's beautiful no ??\n\n");
  usleep(2000000);
  for (i = 0; special2[i]; i++)
    {
      my_printf("%c", special2[i]);
      usleep(100000);
    }
  usleep(2000000);
  my_printf("\n");
  for (i = 0; i < 34; i++)
    {
      my_printf("%s\n", cup[i]);
      usleep(50000);
    }
  my_printf("%s", cup[34]);
  uid = geteuid();
  pw = getpwuid(uid);
  len = my_strlen(pw->pw_name);
  for (i = 0; i < (20 - len) / 2; i++)
    my_printf(" ");
  my_printf("%s", pw->pw_name);
  for (i = 0; i < (20 - len) / 2; i++)
    my_printf(" ");
  for (i = 35; cup[i]; i++)
    {
      my_printf("%s\n", cup[i]);
      usleep(50000);
    }
  return (0);
}
